import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-description-angular',
  templateUrl: './description-angular.component.html',
  styleUrls: ['./description-angular.component.scss']
})
export class DescriptionAngularComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
