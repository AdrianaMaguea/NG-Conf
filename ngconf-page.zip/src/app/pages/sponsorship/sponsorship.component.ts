import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sponsorship',
  templateUrl: './sponsorship.component.html',
  styleUrls: ['./sponsorship.component.scss']
})
export class SponsorshipComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
